FORMULARIO PARA RENDER - MELBOURNE HOUSING

1. Ejecuta completa tu libreta Proyecto_regresion_mes2.ipynb.
2. Al final se deben generar estos archivos:
   - modelo_final.pkl
   - encoder.pkl
   - scaler_general.pkl
   - pca.pkl
   - info_modelo.pkl
3. Copia esos 5 archivos dentro de esta carpeta, al mismo nivel que app.py.
4. Prueba localmente:
   pip install -r requirements.txt
   python app.py
5. Abre:
   http://127.0.0.1:8000
6. Para Render, sube esta carpeta completa a GitHub.
7. En Render usa:
   Build Command: pip install -r requirements.txt
   Start Command: gunicorn app:app
8. Cuando Render genere la URL, pégala en URL_Render.txt y en tu libreta/documento.
